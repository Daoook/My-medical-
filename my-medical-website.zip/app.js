const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const mongoose = require('mongoose');
const app = express();
const port = 3000;

mongoose.connect('mongodb://localhost:27017/mediaDB', { useNewUrlParser: true, useUnifiedTopology: true });

const mediaSchema = new mongoose.Schema({
    url: String,
    mediaType: String,
    uploadDate: { type: Date, default: Date.now }
});

const Media = mongoose.model('Media', mediaSchema);

const uploadDir = 'uploads';
if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir);
}

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, uploadDir);
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + path.extname(file.originalname));
    }
});

const upload = multer({ storage: storage });

app.post('/upload', upload.single('media'), (req, res) => {
    if (!req.file) {
        return res.status(400).json({ success: false, message: 'لم يتم رفع أي ملف.' });
    }

    const fileType = req.file.mimetype.startsWith('image') ? 'image' : 'video';
    const fileUrl = `/uploads/\${req.file.filename}`;

    const newMedia = new Media({
        url: fileUrl,
        mediaType: fileType
    });

    newMedia.save((err) => {
        if (err) {
            return res.status(500).json({ success: false, message: 'حدث خطأ أثناء حفظ الملف في قاعدة البيانات.' });
        }

        res.json({
            success: true,
            mediaType: fileType,
            url: fileUrl
        });
    });
});

app.use('/uploads', express.static('uploads'));
app.use(express.static('public'));

app.listen(port, () => {
    console.log(`Server is running on http://localhost:\${port}`);
});
